This data was collated using AYLIEN's News API -see aylien.com.

Data is presented in JSONL file format with one line per story object.

A story object represents a news article that has been enriched by AYLIEN's NLP technology.

Who can use the data?
These datasets provide a useful resource for evaluating the data that can be extracted via our News API and can not be used in commercial projects.

If you have a particular dataset in mind that you’d like to dive into, please get in touch with us and we’ll see can we build it for you. If you’d like to gather your own, we offer a free 14-day trial of the news intelligence platform.


Financial Crimes Dataset Details:
Size: 0.3 GB (~20,000 news articles)
Language: English content only
Timeframe: May 2019 – Dec 2019
Sources: 147 distinct sources



